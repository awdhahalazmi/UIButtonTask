//
//  ViewController.swift
//  UIButtonTask
//
//  Created by Awdhah Alazemi on 28/02/2024.
//

import UIKit
import SnapKit

class ViewController: UIViewController {
    let myImage = UIImageView()
    let myButton = UIButton(type: .system)
    let myTextField = UITextField()
    var selectedImage = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        subViews()
        setUpUI()
        autoLayout()
        
        myButton.addTarget(self, action: #selector(saveButton), for: .touchUpInside)

        // Do any additional setup after loading the view.
    }
    func subViews( ){
        view.addSubview(myTextField)

        view.addSubview(myButton)
        view.addSubview(myImage)
    }
    func setUpUI(){
       // myImage.image = UIImage(named: "" )
        
       
        myButton.setTitle("Enter", for: .normal)
        myButton.backgroundColor = .gray
        myButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 13)
        myButton.layer.cornerRadius = 10
        myButton.layer.borderWidth = 1
        myButton.tintColor = .white
        
        
        
        //myTextField.placeholder = "write either pandas , qwala or goat"
        myTextField.attributedPlaceholder = NSAttributedString(
            string: "write either pandas , qwala or goat",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.darkGray])
        myTextField.font = UIFont.systemFont(ofSize: 13)
        myTextField.textAlignment = .center
        myTextField.layer.borderColor = UIColor.gray.cgColor
        myTextField.tintColor = .darkGray
        myTextField.keyboardType = .phonePad
        
        
        
    
    }
    func autoLayout(){
        myButton.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.equalTo(100)
            make.height.equalTo(45)
        }
        myTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(myButton.snp.top).offset(-20)
            make.height.equalTo(20)
            make.width.equalTo(300)
            
        }
        myImage.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.bottom.equalTo(myTextField.snp.top)
            make.width.height.equalTo(200)
        }
        
    }
    @objc func saveButton( ){
        
        selectedImage = myTextField.text ?? ""
        
        
        
        
       myImage.image = UIImage(named: selectedImage )
//        myImage.image = UIImage(named: selectedImage )
//        myImage.image = UIImage(named: selectedImage )
//        
        
        
       
    }
}

